package com.jsscoetzer.fynalio;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import android.net.http.SslError;

public final class MainActivity extends Activity {
    private static final String APP_URL = "https://ai-mastering-studio.jsscoetzer.chatgpt.site";
    private static final String APP_HOST = "ai-mastering-studio.jsscoetzer.chatgpt.site";
    private static final int REQUEST_OPEN_FILES = 4101;
    private static final int REQUEST_SAVE_EXPORT = 4102;

    private static final String DOWNLOAD_BRIDGE_SCRIPT =
            "(function(){" +
            "if(window.__fynalioAndroidDownloads)return;" +
            "window.__fynalioAndroidDownloads=true;" +
            "const originalClick=HTMLAnchorElement.prototype.click;" +
            "HTMLAnchorElement.prototype.click=function(){" +
            "const anchor=this,href=anchor.href||'',name=anchor.download||'FYNALIO-export';" +
            "if(window.FynalioAndroid&&anchor.download&&(href.indexOf('blob:')===0||href.indexOf('data:')===0)){" +
            "let transferId='';" +
            "(async function(){try{" +
            "const response=await fetch(href);" +
            "const blob=await response.blob();" +
            "const bytes=new Uint8Array(await blob.arrayBuffer());" +
            "transferId=window.FynalioAndroid.beginDownload(name,blob.type||'application/octet-stream',bytes.length);" +
            "if(!transferId)throw new Error('Could not prepare export');" +
            "const chunkSize=196608;" +
            "for(let offset=0;offset<bytes.length;offset+=chunkSize){" +
            "const end=Math.min(offset+chunkSize,bytes.length);let binary='';" +
            "for(let part=offset;part<end;part+=32768){" +
            "binary+=String.fromCharCode.apply(null,bytes.subarray(part,Math.min(part+32768,end)));" +
            "}" +
            "window.FynalioAndroid.writeChunk(transferId,btoa(binary));" +
            "}" +
            "window.FynalioAndroid.finishDownload(transferId);" +
            "}catch(error){window.FynalioAndroid.failDownload(transferId,String(error));}})();" +
            "return;" +
            "}" +
            "return originalClick.apply(anchor,arguments);" +
            "};" +
            "})();";

    private final ConcurrentHashMap<String, ExportTransfer> transfers = new ConcurrentHashMap<>();
    private final ArrayDeque<ExportTransfer> saveQueue = new ArrayDeque<>();

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout errorView;
    private ValueCallback<Uri[]> pendingFileChooser;
    private ExportTransfer pendingSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        } else {
            root.setFitsSystemWindows(true);
        }

        webView = buildWebView();
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        errorView = buildErrorView();
        errorView.setVisibility(View.GONE);
        root.addView(errorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#B6FF00")));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#171717")));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(3)
        );
        progressParams.gravity = Gravity.TOP;
        root.addView(progressBar, progressParams);

        setContentView(root);

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            webView.loadUrl(APP_URL);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private WebView buildWebView() {
        WebView view = new WebView(this);
        view.setBackgroundColor(Color.BLACK);
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " FynalioAndroid/0.1.1-beta");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(view, false);

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        view.addJavascriptInterface(new DownloadBridge(), "FynalioAndroid");
        view.setWebViewClient(new FynalioWebViewClient());
        view.setWebChromeClient(new FynalioChromeClient());
        view.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || url.startsWith("blob:") || url.startsWith("data:")) return;
            openExternal(Uri.parse(url));
        });
        return view;
    }

    private LinearLayout buildErrorView() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(32), dp(32), dp(32), dp(32));
        panel.setBackgroundColor(Color.parseColor("#050505"));

        TextView title = new TextView(this);
        title.setText(R.string.offline_title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        panel.addView(title);

        TextView message = new TextView(this);
        message.setText(R.string.offline_message);
        message.setTextColor(Color.parseColor("#B5B5B5"));
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams messageParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        messageParams.setMargins(0, dp(12), 0, dp(24));
        panel.addView(message, messageParams);

        Button retry = new Button(this);
        retry.setText(R.string.retry);
        retry.setTextColor(Color.BLACK);
        retry.setTextSize(16);
        retry.setAllCaps(false);
        retry.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#B6FF00")));
        retry.setOnClickListener(button -> {
            hideError();
            webView.loadUrl(APP_URL);
        });
        panel.addView(retry, new LinearLayout.LayoutParams(dp(180), dp(52)));
        return panel;
    }

    private final class FynalioWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            hideError();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progressBar.setVisibility(View.GONE);
            if (isTrustedUrl(Uri.parse(url))) {
                view.evaluateJavascript(DOWNLOAD_BRIDGE_SCRIPT, null);
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) return false;
            return handleNavigation(request.getUrl());
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleNavigation(Uri.parse(url));
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) showError();
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            if (request.isForMainFrame() && errorResponse.getStatusCode() >= 500) showError();
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            showError();
        }
    }

    private final class FynalioChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int progress) {
            progressBar.setProgress(progress);
            progressBar.setVisibility(progress >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public boolean onShowFileChooser(
                WebView view,
                ValueCallback<Uri[]> filePathCallback,
                FileChooserParams fileChooserParams
        ) {
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
            pendingFileChooser = filePathCallback;

            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("*/*");
            picker.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "audio/*",
                    "application/zip",
                    "application/x-zip-compressed",
                    "image/*"
            });
            picker.putExtra(
                    Intent.EXTRA_ALLOW_MULTIPLE,
                    fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE
            );

            try {
                startActivityForResult(picker, REQUEST_OPEN_FILES);
                return true;
            } catch (ActivityNotFoundException exception) {
                pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = null;
                Toast.makeText(MainActivity.this, "No file picker is available.", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    private boolean handleNavigation(Uri uri) {
        if (isReservedAuthUrl(uri)) {
            webView.stopLoading();
            webView.loadUrl(APP_URL);
            return true;
        }
        if (isTrustedUrl(uri) || "about".equalsIgnoreCase(uri.getScheme())) return false;
        openExternal(uri);
        return true;
    }

    private boolean isReservedAuthUrl(Uri uri) {
        String host = uri.getHost();
        String path = uri.getPath();
        if (host != null && host.equalsIgnoreCase("auth.openai.com")) return true;
        if (host == null || !host.equalsIgnoreCase(APP_HOST) || path == null) return false;
        return path.equals("/signin-with-chatgpt")
                || path.equals("/signout-with-chatgpt")
                || path.equals("/callback");
    }

    private boolean isTrustedUrl(Uri uri) {
        return "https".equalsIgnoreCase(uri.getScheme()) && APP_HOST.equalsIgnoreCase(uri.getHost());
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this, "No app can open this link.", Toast.LENGTH_LONG).show();
        }
    }

    private final class DownloadBridge {
        @JavascriptInterface
        public String beginDownload(String requestedName, String requestedMime, long expectedBytes) {
            String id = UUID.randomUUID().toString();
            try {
                String name = sanitiseFilename(requestedName);
                String mime = requestedMime == null || requestedMime.trim().isEmpty()
                        ? "application/octet-stream"
                        : requestedMime;
                File temp = File.createTempFile("fynalio-export-", ".part", getCacheDir());
                ExportTransfer transfer = new ExportTransfer(
                        id,
                        name,
                        mime,
                        expectedBytes,
                        temp,
                        new FileOutputStream(temp)
                );
                transfers.put(id, transfer);
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Preparing " + name + "…",
                        Toast.LENGTH_SHORT
                ).show());
                return id;
            } catch (IOException exception) {
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "FYNALIO could not prepare the export.",
                        Toast.LENGTH_LONG
                ).show());
                return "";
            }
        }

        @JavascriptInterface
        public void writeChunk(String id, String base64Chunk) {
            ExportTransfer transfer = transfers.get(id);
            if (transfer == null || base64Chunk == null) return;
            try {
                byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
                synchronized (transfer) {
                    if (transfer.closed) return;
                    transfer.output.write(bytes);
                    transfer.bytesWritten += bytes.length;
                }
            } catch (Exception exception) {
                abortTransfer(id);
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "The export could not be transferred to Android.",
                        Toast.LENGTH_LONG
                ).show());
            }
        }

        @JavascriptInterface
        public void finishDownload(String id) {
            ExportTransfer transfer = transfers.remove(id);
            if (transfer == null) return;
            try {
                synchronized (transfer) {
                    if (!transfer.closed) {
                        transfer.output.flush();
                        transfer.output.close();
                        transfer.closed = true;
                    }
                }
                runOnUiThread(() -> enqueueSave(transfer));
            } catch (IOException exception) {
                transfer.tempFile.delete();
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "FYNALIO could not finish the export.",
                        Toast.LENGTH_LONG
                ).show());
            }
        }

        @JavascriptInterface
        public void failDownload(String id, String ignoredReason) {
            if (id != null && !id.isEmpty()) abortTransfer(id);
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "FYNALIO could not create that export.",
                    Toast.LENGTH_LONG
            ).show());
        }
    }

    private void enqueueSave(ExportTransfer transfer) {
        saveQueue.add(transfer);
        startNextSave();
    }

    private void startNextSave() {
        if (pendingSave != null || saveQueue.isEmpty()) return;
        pendingSave = saveQueue.removeFirst();

        Intent saver = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        saver.addCategory(Intent.CATEGORY_OPENABLE);
        saver.setType(pendingSave.mimeType);
        saver.putExtra(Intent.EXTRA_TITLE, pendingSave.filename);
        try {
            startActivityForResult(saver, REQUEST_SAVE_EXPORT);
        } catch (ActivityNotFoundException exception) {
            ExportTransfer fallback = pendingSave;
            pendingSave = null;
            saveToDownloadsFallback(fallback);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OPEN_FILES) {
            ValueCallback<Uri[]> callback = pendingFileChooser;
            pendingFileChooser = null;
            if (callback == null) return;
            callback.onReceiveValue(resultCode == RESULT_OK ? collectSelectedUris(data) : null);
            return;
        }

        if (requestCode == REQUEST_SAVE_EXPORT) {
            ExportTransfer transfer = pendingSave;
            pendingSave = null;
            if (transfer == null) {
                startNextSave();
                return;
            }

            Uri destination = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if (destination == null) {
                transfer.tempFile.delete();
                startNextSave();
            } else {
                copyExportToUri(transfer, destination);
            }
        }
    }

    private Uri[] collectSelectedUris(Intent data) {
        if (data == null) return null;
        List<Uri> uris = new ArrayList<>();
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int index = 0; index < clipData.getItemCount(); index++) {
                Uri uri = clipData.getItemAt(index).getUri();
                if (uri != null) uris.add(uri);
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        return uris.isEmpty() ? null : uris.toArray(new Uri[0]);
    }

    private void copyExportToUri(ExportTransfer transfer, Uri destination) {
        new Thread(() -> {
            boolean success = false;
            try (InputStream input = new FileInputStream(transfer.tempFile);
                 OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                if (output == null) throw new IOException("No destination stream");
                copy(input, output);
                success = true;
            } catch (IOException ignored) {
                // A user-facing result is posted below.
            } finally {
                transfer.tempFile.delete();
            }

            boolean completed = success;
            runOnUiThread(() -> {
                Toast.makeText(
                        MainActivity.this,
                        completed ? "Saved " + transfer.filename : "FYNALIO could not save that file.",
                        completed ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG
                ).show();
                startNextSave();
            });
        }, "fynalio-export-save").start();
    }

    private void saveToDownloadsFallback(ExportTransfer transfer) {
        new Thread(() -> {
            boolean success = false;
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, transfer.filename);
                    values.put(MediaStore.Downloads.MIME_TYPE, transfer.mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FYNALIO");
                    Uri destination = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (destination == null) throw new IOException("No Downloads destination");
                    try (InputStream input = new FileInputStream(transfer.tempFile);
                         OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                        if (output == null) throw new IOException("No destination stream");
                        copy(input, output);
                    }
                    success = true;
                } else {
                    File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "FYNALIO");
                    if (!folder.exists() && !folder.mkdirs()) throw new IOException("Could not create export folder");
                    File destination = new File(folder, transfer.filename);
                    try (InputStream input = new FileInputStream(transfer.tempFile);
                         OutputStream output = new FileOutputStream(destination)) {
                        copy(input, output);
                    }
                    success = true;
                }
            } catch (IOException ignored) {
                // A user-facing result is posted below.
            } finally {
                transfer.tempFile.delete();
            }

            boolean completed = success;
            runOnUiThread(() -> {
                Toast.makeText(
                        MainActivity.this,
                        completed ? "Saved " + transfer.filename + " to Downloads/FYNALIO" : "FYNALIO could not save that file.",
                        completed ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG
                ).show();
                startNextSave();
            });
        }, "fynalio-export-fallback").start();
    }

    private static void copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        int count;
        while ((count = input.read(buffer)) != -1) {
            output.write(buffer, 0, count);
        }
        output.flush();
    }

    private void abortTransfer(String id) {
        ExportTransfer transfer = transfers.remove(id);
        if (transfer == null) return;
        synchronized (transfer) {
            try {
                if (!transfer.closed) transfer.output.close();
            } catch (IOException ignored) {
                // Cleanup continues below.
            }
            transfer.closed = true;
        }
        transfer.tempFile.delete();
    }

    private static String sanitiseFilename(String requestedName) {
        String fallback = "FYNALIO-export";
        if (requestedName == null) return fallback;
        String cleaned = requestedName.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (cleaned.isEmpty()) return fallback;
        return cleaned.length() > 180 ? cleaned.substring(0, 180) : cleaned;
    }

    private void showError() {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            errorView.setVisibility(View.VISIBLE);
        });
    }

    private void hideError() {
        if (errorView != null) errorView.setVisibility(View.GONE);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (errorView.getVisibility() == View.VISIBLE) {
            hideError();
            webView.loadUrl(APP_URL);
        } else if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        webView.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
        for (String id : new ArrayList<>(transfers.keySet())) abortTransfer(id);
        if (pendingSave != null) pendingSave.tempFile.delete();
        for (ExportTransfer transfer : saveQueue) transfer.tempFile.delete();
        saveQueue.clear();
        if (webView != null) {
            webView.removeJavascriptInterface("FynalioAndroid");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private static final class ExportTransfer {
        final String id;
        final String filename;
        final String mimeType;
        final long expectedBytes;
        final File tempFile;
        final FileOutputStream output;
        long bytesWritten;
        boolean closed;

        ExportTransfer(
                String id,
                String filename,
                String mimeType,
                long expectedBytes,
                File tempFile,
                FileOutputStream output
        ) {
            this.id = id;
            this.filename = filename;
            this.mimeType = mimeType;
            this.expectedBytes = expectedBytes;
            this.tempFile = tempFile;
            this.output = output;
        }
    }
}
