# R8 is disabled for the beta build. Keep this file for the production hardening pass.
