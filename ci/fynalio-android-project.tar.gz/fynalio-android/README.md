# FYNALIO Android beta v0.1.1

Installable Android shell for the public FYNALIO mastering app.

The native layer provides:

- Android document picker support for songs, stems ZIP files, and cover art
- native save-location prompts for generated WAV and MP3 exports
- hardware-accelerated Web Audio playback and processing
- secure-screen protection
- a branded launcher icon, splash screen, progress state, and offline retry state
- automatic use of the newest published FYNALIO version
- a hard block against obsolete ChatGPT sign-in and callback routes

This beta package intentionally uses a separate application ID and a dedicated test signing key.
